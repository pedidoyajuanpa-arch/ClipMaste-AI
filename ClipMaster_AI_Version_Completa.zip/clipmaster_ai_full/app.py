import os, re, uuid, subprocess, shutil
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, HttpUrl, Field

BASE = Path(__file__).parent
WORK = BASE / "work"
WORK.mkdir(exist_ok=True)
app = FastAPI(title="ClipMaster AI", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

class ClipRequest(BaseModel):
    url: HttpUrl
    mode: str = Field(default="auto", pattern="^(auto|manual)$")
    duration: int = Field(default=30, ge=5, le=180)
    count: int = Field(default=5, ge=1, le=20)
    aspect: str = Field(default="9:16", pattern="^(9:16|1:1|16:9)$")
    start: Optional[float] = Field(default=0, ge=0)
    end: Optional[float] = Field(default=None, gt=0)
    subtitles: bool = True

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout)[-2500:])
    return p.stdout

def ffmpeg_path():
    p = shutil.which("ffmpeg")
    if not p:
        raise HTTPException(500, "FFmpeg no está instalado en el servidor.")
    return p

def get_duration(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return float(out.strip())

def download_video(url, folder):
    # yt-dlp is intended only for videos the user owns or is authorized to download.
    out = str(folder / "source.%(ext)s")
    try:
        run(["yt-dlp", "--no-playlist", "--max-filesize", "500M",
             "-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b",
             "--merge-output-format", "mp4", "-o", out, str(url)])
    except RuntimeError as e:
        raise HTTPException(400, "No se pudo obtener el video. Verifica que sea accesible y que tengas permiso para descargarlo. " + str(e))
    candidates = list(folder.glob("source.*"))
    candidates = [p for p in candidates if p.suffix.lower() in [".mp4", ".mkv", ".webm", ".mov"]]
    if not candidates:
        raise HTTPException(400, "No se encontró un archivo de video compatible.")
    return candidates[0]

def transcribe_segments(video, folder):
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return []
    # Extract audio and transcribe through OpenAI's audio transcription endpoint.
    audio = folder / "audio.mp3"
    run(["ffmpeg", "-y", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
         "-b:a", "64k", str(audio)])
    try:
        from openai import OpenAI
        client = OpenAI(api_key=key)
        with open(audio, "rb") as f:
            result = client.audio.transcriptions.create(
                model=os.getenv("OPENAI_TRANSCRIBE_MODEL", "whisper-1"),
                file=f, response_format="verbose_json", timestamp_granularities=["segment"]
            )
        return [s for s in (getattr(result, "segments", None) or [])]
    except Exception:
        return []

def choose_auto_segments(total, duration, count, segments):
    # Score speech segments for useful, non-overlapping highlight windows.
    candidates = []
    if segments:
        for s in segments:
            st = float(getattr(s, "start", 0))
            en = float(getattr(s, "end", st + duration))
            text = getattr(s, "text", "") or ""
            score = min(len(text), 180) + (12 if "?" in text or "!" in text else 0)
            center = (st + en) / 2
            a = max(0, min(total-duration, center-duration/2))
            candidates.append((score, a, min(total, a+duration)))
    if not candidates:
        # Useful no-key fallback: distribute clips over the full video.
        if total <= duration:
            return [(0, total)]
        step = max(duration, (total-duration)/max(1, count-1))
        return [(min(total-duration, i*step), min(total, min(total-duration, i*step)+duration))
                for i in range(count)]
    candidates.sort(reverse=True)
    chosen = []
    for _, a, b in candidates:
        if all(abs(a-x) > duration*0.65 for x, _ in chosen):
            chosen.append((a,b))
        if len(chosen) >= count:
            break
    return sorted(chosen or [(0, min(total,duration))])

def render_clip(src, folder, idx, start, end, aspect, subtitles):
    ffmpeg = ffmpeg_path()
    out = folder / f"clip_{idx:02d}.mp4"
    if aspect == "9:16":
        vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
    elif aspect == "1:1":
        vf = "scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080"
    else:
        vf = "scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080"
    # Encode to widely compatible H.264/AAC MP4.
    run([ffmpeg, "-y", "-ss", str(start), "-i", str(src), "-t", str(max(1,end-start)),
         "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
         "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(out)])
    return out

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"ok": True, "service": "ClipMaster AI"}

@app.post("/api/create")
def create(req: ClipRequest):
    job = uuid.uuid4().hex[:12]
    folder = WORK / job
    folder.mkdir()
    try:
        source = download_video(str(req.url), folder)
        total = get_duration(source)
        if req.mode == "manual":
            if req.end is None or req.end <= req.start:
                raise HTTPException(400, "En modo manual, el final debe ser mayor que el inicio.")
            if req.start >= total:
                raise HTTPException(400, "El inicio supera la duración del video.")
            segments = [(req.start, min(req.end, total))]
        else:
            transcript = transcribe_segments(source, folder)
            segments = choose_auto_segments(total, req.duration, req.count, transcript)
        results = []
        for i, (a,b) in enumerate(segments, 1):
            path = render_clip(source, folder, i, a, b, req.aspect, req.subtitles)
            results.append({"name": path.name, "url": f"/api/download/{job}/{path.name}",
                            "start": round(a,1), "end": round(b,1)})
        return {"job": job, "clips": results,
                "note": "Análisis de voz con IA activo." if os.getenv("OPENAI_API_KEY") and req.mode=="auto"
                        else ("Modo automático: selección distribuida; configura OPENAI_API_KEY para analizar la transcripción." if req.mode=="auto" else "Clip manual procesado.")}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, "Error al procesar el video: " + str(e))
    finally:
        # Keep generated clips for download; source cleanup can be scheduled on production hosting.
        pass

@app.get("/api/download/{job}/{filename}")
def download(job: str, filename: str):
    if not re.fullmatch(r"[a-f0-9]{12}", job) or not re.fullmatch(r"clip_\d{2}\.mp4", filename):
        raise HTTPException(404, "Archivo no encontrado.")
    path = WORK / job / filename
    if not path.exists():
        raise HTTPException(404, "El clip ya no está disponible.")
    return FileResponse(path, media_type="video/mp4", filename=filename)
