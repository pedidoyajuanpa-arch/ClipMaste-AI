# ClipMaster AI

Aplicación web para crear clips MP4 desde enlaces de videos que el usuario posee o está autorizado a descargar.

## Funciones
- Interfaz en español, adaptable a móviles.
- Vista previa embebida de YouTube.
- Modo manual: selecciona inicio y final.
- Modo automático: genera varios segmentos distribuidos. Si configuras `OPENAI_API_KEY`, intenta usar transcripción de audio para priorizar segmentos con más contenido hablado.
- Exportación MP4 H.264/AAC con FFmpeg.
- Formatos vertical 9:16, cuadrado 1:1 y horizontal 16:9.
- Descarga individual de clips.
- Límite de descarga configurado en 500 MB.

## Ejecutar localmente
Requisitos: Python 3.11+, FFmpeg y ffprobe instalados.

```bash
pip install -r requirements.txt
uvicorn app:app --reload
```
Abre http://localhost:8000

## Activar análisis de transcripción
Crea una variable de entorno `OPENAI_API_KEY` con tu propia clave. Sin ella, el modo automático selecciona segmentos distribuidos a lo largo del video. La clave no debe colocarse en el navegador ni compartirse.

## Publicar en Render
1. Sube todos los archivos del proyecto a un repositorio privado de GitHub.
2. En Render, crea un servicio nuevo desde ese repositorio.
3. Render detectará el `Dockerfile`.
4. En Environment agrega `OPENAI_API_KEY` si quieres análisis por transcripción.
5. Despliega y prueba `/health`.

## Importante
Descarga y procesa únicamente contenido propio o para el que tengas permiso. La disponibilidad de videos y la posibilidad de descargarlos depende de la plataforma, los derechos y las restricciones técnicas. Esta versión no publica automáticamente en TikTok, Facebook o YouTube; exporta los MP4 para que puedas subirlos.
